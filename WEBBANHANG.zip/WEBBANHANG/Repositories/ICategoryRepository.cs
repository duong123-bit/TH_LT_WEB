﻿using WEBBANHANG.Models;

namespace WEBBANHANG.Repositories
{
    public interface ICategoryRepository
    {
        IEnumerable<Category> GetAllCategories();
    }
}
